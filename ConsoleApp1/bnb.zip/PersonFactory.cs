﻿public class PersonFactory
{
    //public  MakePerson(string type, string firstname, string lastname, int age,string city, int salary)
    //{
       // if (type == "customer")
        //{
       //     return new Customer(firstname, lastname, age, city, salary);
       // }
       // else if(type == "Owner")
       // {
      //      return new Owner(firstname, lastname, age, city, salary);
       // }
   // }
}